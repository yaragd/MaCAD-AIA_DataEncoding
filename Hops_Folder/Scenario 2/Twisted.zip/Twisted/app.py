from flask import Flask
from logging import debug
import rhinoinside
import ghhops_server as hs
import runPythonapp as myML
import rhino3dm as r
rhinoinside.load(str())
import Rhino 
import Rhino.Geometry as rg


app = Flask(__name__)
hops = hs.Hops(app)

@hops.component(
    "/sunTK",  #this is what we have to write in hops address, like http://127.0.0.1:5000/pointat
    name="predictSunAccess",
    description="predict sunAccess",
    inputs=[
        hs.HopsNumber("a", "Vol", "Volume"),
        hs.HopsNumber("b", "TotalA", "Total Area"),
        hs.HopsNumber("c", "NoFl", "# of Floors"),
        hs.HopsNumber("d", "Bhei", "Building Heigth"),
        hs.HopsNumber("e", "RotAng", "Rotation Angle"),
        
        
    ],
    outputs=[
        hs.HopsNumber("prediction", "DSH", "prediction", hs.HopsParamAccess.LIST )
    ]
)

def predictions( a, b, c, d, e):

    pred = myML.predictions(a,b,c,d,e)
    return pred


@hops.component(
    "/sunTKB",  #this is what we have to write in hops address, like http://127.0.0.1:5000/pointat
    name="predictSunAccess",
    description="predict sunAccess",
    inputs=[
        hs.HopsNumber("a", "Vol", "Volume"),
        hs.HopsNumber("b", "TotalA", "Total Area"),
        hs.HopsNumber("c", "NoFl", "# of Floors"),
        hs.HopsNumber("d", "Bhei", "Building Heigth"),
        hs.HopsNumber("e", "RotAng", "Rotation Angle"),
        
        
    ],
    outputs=[
        hs.HopsNumber("prediction", "DSH", "prediction", hs.HopsParamAccess.LIST )
    ]
)

def predictions( a, b, c, d, e):

    pred = myML.predictions(a,b,c,d,e)
    return pred








if __name__ == "__main__":
    app.run(debug=True)